.. automodule:: scipy.cluster
   :no-members:
   :no-inherited-members:
   :no-special-members:

.. toctree::
   :hidden:

   cluster.vq
   cluster.hierarchy
