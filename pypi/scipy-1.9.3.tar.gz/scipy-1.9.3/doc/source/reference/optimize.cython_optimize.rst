.. automodule:: scipy.optimize.cython_optimize
