.. _optimize.linprog-simplex:

linprog(method='simplex')
----------------------------------------

.. scipy-optimize:function:: scipy.optimize.linprog
   :impl: scipy.optimize._linprog._linprog_simplex_doc
   :method: simplex
