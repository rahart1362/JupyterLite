.. automodule:: scipy.interpolate
   :no-members:
   :no-inherited-members:
   :no-special-members:
