.. _whatsnew:

What's new in each version
==========================

v0.12
-----
.. toctree::
   :maxdepth: 2

   v0.12.2
   v0.12.1
   v0.12.0

v0.11
-----
.. toctree::
   :maxdepth: 2

   v0.11.2
   v0.11.1
   v0.11.0

v0.10
-----
.. toctree::
   :maxdepth: 2

   v0.10.1
   v0.10.0

v0.9
----
.. toctree::
   :maxdepth: 2

   v0.9.1
   v0.9.0

v0.8
----
.. toctree::
   :maxdepth: 2

   v0.8.1
   v0.8.0

v0.7
----
.. toctree::
   :maxdepth: 2

   v0.7.1
   v0.7.0

v0.6
----
.. toctree::
   :maxdepth: 2

   v0.6.0

v0.5
----
.. toctree::
   :maxdepth: 2

   v0.5.1
   v0.5.0

v0.4
----
.. toctree::
   :maxdepth: 2

   v0.4.0

v0.3
----
.. toctree::
   :maxdepth: 2

   v0.3.1
   v0.3.0

v0.2
----
.. toctree::
   :maxdepth: 2

   v0.2.1
   v0.2.0
